(function($) {

	"use strict";

})(jQuery);
